spatial.hm.all <- function() {

  library(shiny)
  path <- system.file("extdata", package = "spatialHeatmap")
  runApp(path)

}

